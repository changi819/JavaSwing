package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import db.Dbprocess;
import db.MemberDAO;
import db.MemberDTO;
import db.ScoreDTO;

public class 로그인 {
	private static JTextField t1;
	private static JTextField t2;
	
	public static void main(String[] args) {
		JFrame f = new JFrame();
		Search se = new Search();
		f.getContentPane().setBackground(new Color(51, 153, 255));
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);
		//db.realdata();
		se.searchWindow();

		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514 \uB85C\uADF8\uC778");
		lblNewLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
		lblNewLabel.setBounds(40, 46, 172, 48);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_2 = new JLabel("\uC544\uC774\uB514:");
		lblNewLabel_2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(40, 134, 97, 58);
		f.getContentPane().add(lblNewLabel_2);

		t1 = new JTextField();
		t1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		t1.setColumns(10);
		t1.setBounds(152, 155, 254, 23);
		f.getContentPane().add(t1);

		JLabel lblNewLabel_3 = new JLabel("\uBE44\uBC00\uBC88\uD638:");
		lblNewLabel_3.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(40, 189, 103, 41);
		f.getContentPane().add(lblNewLabel_3);

		t2 = new JTextField();
		t2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		t2.setColumns(10);
		t2.setBounds(152, 201, 254, 23);
		f.getContentPane().add(t2);
		
		// 로그인 버튼
		JButton btnNewButton_1 = new JButton("\uB85C\uADF8\uC778");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = t1.getText();
				MemberDTO.id = t1.getText();
	            String pw = t2.getText();
	            MemberDTO.pw = t2.getText();
	            MemberDAO dao = new MemberDAO();
	            boolean result2 = dao.select2(id,pw);
	            // null일 가능성 체크
	            if (result2 == true) {
	               JOptionPane.showMessageDialog(null, "로그인이 완료되었습니다.");
	               Search se = new Search();
	               dao.getNickName();
	               se.searchWindow();
	               f.dispose();
	            } else {
	               JOptionPane.showMessageDialog(null, "해당 회원이 아닙니다.");
	               t1.setText("");
	               t2.setText("");
	            }
			}
		});
		btnNewButton_1.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
		btnNewButton_1.setBounds(66, 315, 340, 80);
		f.getContentPane().add(btnNewButton_1);
		// 회원가입 버튼
		JButton btnNewButton = new JButton("\uD68C\uC6D0\uAC00\uC785\uC744 \uC548\uD558\uC168\uB098\uC694?");
		btnNewButton.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SignIn sign = new SignIn();
				sign.signIn();
			}
		});
		btnNewButton.setBounds(215, 261, 191, 23);
		f.getContentPane().add(btnNewButton);
		f.setVisible(true);

	}
}
