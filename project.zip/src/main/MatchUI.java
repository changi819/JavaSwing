package main;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

import db.Crawling;
import db.DAO;
import db.DTO;
import db.MemberDTO;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.TextArea;

public class MatchUI {
   private static final JScrollPane scrollPane = new JScrollPane();
   /**
    * @wbp.parser.entryPoint
    */
   public void match() {
      JFrame f = new JFrame();
      f.getContentPane().setBackground(new Color(100, 149, 237));
      f.getContentPane().setLayout(null);
      
      JLabel lblNewLabel = new JLabel("자동 매칭");
      lblNewLabel.setFont(new Font("굴림", Font.BOLD, 25));
      lblNewLabel.setBounds(38, 10, 177, 48);
      f.getContentPane().add(lblNewLabel);
      
      JPanel panel = new JPanel();
      panel.setBounds(12, 68, 655, 243);
      f.getContentPane().add(panel);
      panel.setLayout(null);
      
      JLabel lblNewLabel_1 = new JLabel("내 정보");
      lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 20));
      lblNewLabel_1.setBounds(12, 10, 129, 41);
      panel.add(lblNewLabel_1);
      
      TextArea textArea = new TextArea();
      textArea.setFont(new Font("Dialog", Font.PLAIN, 20));
      textArea.setBounds(143, 10, 500, 160);
      panel.add(textArea);
      
      JButton btnNewButton_2_1_1 = new JButton("정보 삭제");
      btnNewButton_2_1_1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            DAO dao2 = new DAO();
            if (dao2.search(MemberDTO.id)) {
               dao2.delete(MemberDTO.id);
               JOptionPane.showMessageDialog(null, "삭제되었습니다.");
               textArea.setText("");
            } else {
               JOptionPane.showMessageDialog(null, "삭제할 정보가 없습니다.");
            }
         }
      });
      btnNewButton_2_1_1.setBounds(536, 192, 107, 41);
      panel.add(btnNewButton_2_1_1);
      
      JButton btnNewButton_2_1_2 = new JButton("내 정보 등록");
      btnNewButton_2_1_2.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            String id = MemberDTO.id;
            String nick = MemberDTO.nickname; //로그인 시 사용한 ID와 닉네임
            
            DAO dao = new DAO();
            ArrayList list = dao.select4(MemberDTO.nickname);
            String tier = String.valueOf(list.get(0));
            System.out.println(tier);
            double rate = ((double) list.get(1))* 100; //그 닉네임으로 검색한 티어와 승률

            MatchUI2 ui = new MatchUI2();
            ui.match(id, nick, tier, rate); //DB에 저장
         }
      });
      btnNewButton_2_1_2.setBounds(418, 192, 107, 41);
      panel.add(btnNewButton_2_1_2);
      
      JButton btnNewButton_2_1_2_2 = new JButton("새로고침");
      btnNewButton_2_1_2_2.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            DAO dao = new DAO();
            ArrayList list2 = dao.select4(MemberDTO.nickname);
            String tier = String.valueOf(list2.get(0));
            double rate = ((double)list2.get(1)) * 100;
            
            if (dao.search(MemberDTO.id)) {
               DAO dao3 = new DAO();
               ArrayList list3 = dao3.search2(MemberDTO.nickname);
               String champ = String.valueOf(list3.get(0));
               String position = String.valueOf(list3.get(1));
               textArea.setText("게임 ID : " + MemberDTO.nickname + '\n' + "티어 : " + tier + '\n' +
                     "주 챔피언 : " + champ + '\n' + "포지션 : " + position + '\n' + "승률 : " + String.format("%.2f", rate) + "%");
            } else {
               textArea.setText("");
            }
         }
      });
      btnNewButton_2_1_2_2.setBounds(12, 60, 107, 41);
      panel.add(btnNewButton_2_1_2_2);
      
      DAO dao = new DAO();
      ArrayList list2 = dao.select4(MemberDTO.nickname);
      String tier = String.valueOf(list2.get(0));
      double rate = ((double)list2.get(1)) * 100;
      
      if (dao.search(MemberDTO.id)) { // 내 정보가 DB에 저장되 있으면 게임 ID, 티어, 주 챔피언, 포지션, 승률 출력
         DAO dao3 = new DAO();
         ArrayList list3 = dao3.search2(MemberDTO.nickname);
         String champ = String.valueOf(list3.get(0));
         String position = String.valueOf(list3.get(1));
         textArea.setText("게임 ID : " + MemberDTO.nickname + '\n' + "티어 : " + tier + '\n' +
               "주 챔피언 : " + champ + '\n' + "포지션 : " + position + '\n' + "승률 : " + String.format("%.2f", rate) + "%");
      } else {
         textArea.setText("");
      }
      
      JPanel panel_1 = new JPanel();
      panel_1.setBounds(12, 323, 655, 398);
      f.getContentPane().add(panel_1);
      panel_1.setLayout(null);
      
      
      JList list = new JList();
      scrollPane.setViewportView(list);
      
      DefaultListModel listModel = new DefaultListModel();
        
        Crawling cr = new Crawling();
        ArrayList<String> name = cr.name();
        for (String s : name) {
           listModel.addElement(s);
        }
        
        list.setModel(listModel);
        
      
      JScrollPane scrollPane_1 = new JScrollPane();
      scrollPane_1.setBounds(269, 52, 255, 325);
      panel_1.add(scrollPane_1);
      
      String[] position = { "Top", "Bottom" ,"Mid", "Support", "Jungle" };
      JList list_1 = new JList();
      scrollPane_1.setViewportView(list_1);
      
      DefaultListModel listModel_1 = new DefaultListModel();
      for (String s : position) {
              listModel_1.addElement(s);
           }
           
        list_1.setModel(listModel_1);
      
      JLabel lblNewLabel_1_1 = new JLabel("선택 옵션");
      lblNewLabel_1_1.setFont(new Font("굴림", Font.PLAIN, 20));
      lblNewLabel_1_1.setBounds(12, 0, 129, 51);
      panel_1.add(lblNewLabel_1_1);
      f.setSize(693, 768);
      
      JButton btnNewButton_2_1_2_1 = new JButton("자동 매칭");
      btnNewButton_2_1_2_1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            String champ = String.valueOf(list.getSelectedValue());
            String position = String.valueOf(list_1.getSelectedValue());  
            DAO dao = new DAO();
            ArrayList list2 = dao.select4(MemberDTO.nickname); //내가 선택한 champ, position 값으로 매칭할 유저 selet
            String tier = String.valueOf(list2.get(0));
            ArrayList<DTO> list = dao.search3(tier, champ, position);
            MatchUI3 ui = new MatchUI3();
            ui.ui(list);
         }
      });
      btnNewButton_2_1_2_1.setBounds(536, 347, 107, 41);
      panel_1.add(btnNewButton_2_1_2_1);
      scrollPane.setBounds(12, 52, 255, 325);
      panel_1.add(scrollPane);
      
      f.setVisible(true);
   }
}