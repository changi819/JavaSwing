package main;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import db.DAO;
import db.DTO;
import main.PieChartMain;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;

public class RankingUI {
   private static JTable table;

   public void RankingMain() {
      JFrame f = new JFrame();
      f.getContentPane().setBackground(new Color(100, 149, 237));
      f.setSize(1230, 761);
      f.getContentPane().setLayout(null);

      JLabel lblNewLabel = new JLabel("    \uB7AD\uD0B9");
      lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 30));
      lblNewLabel.setBounds(26, 10, 118, 53);
      f.getContentPane().add(lblNewLabel);

      String[] tier = { "Iron", "Bronze", "Silver", "Gold", "Platinum", "Diamond", "Master", "Grand Master",
            "Challenger" };
      JList list_1 = new JList();
      list_1.setBounds(999, 153, 205, 300);
      list_1.setFont(new Font("굴림", Font.BOLD, 25));
      f.getContentPane().add(list_1);

      DAO dao = new DAO();
      ArrayList<DTO> list = dao.select5();

      Object[] title = { "순위", "게임 ID", "티어", "승률", "총 플레이 수", "이긴 횟수" };
      Object[][] contents = new Object[list.size()][];
      for (int i = 0; i < list.size(); i++) {
         Object[] row = new Object[6];
         DTO dto = list.get(i);
         row[0] = (i + 1) + "위";
         row[1] = dto.getNickname();
         row[2] = dto.getTier();
         row[3] = String.format("%.2f", dto.getRate() * 100) + "%";
         row[4] = dto.getCount();
         row[5] = dto.getWin();
         contents[i] = row;
      }

      DefaultTableModel mod = new DefaultTableModel(contents, title) {
         public boolean isCellEditable(int rowIndex, int mColIndex) {
            return false;
         }
      };
      table = new JTable(mod);
      table.setFont(new Font("굴림", Font.BOLD, 25));
      table.setRowHeight(50);
      table.setCellSelectionEnabled(true);
      table.getTableHeader().setReorderingAllowed(false);
      table.getTableHeader().setResizingAllowed(false);

      JScrollPane scrollPane = new JScrollPane();
      scrollPane.setViewportView(table);
      scrollPane.setBounds(12, 76, 975, 638);
      f.getContentPane().add(scrollPane);

      JButton btnNewButton_1 = new JButton("새로고침");
      btnNewButton_1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            DAO dao = new DAO();
            ArrayList<DTO> list = dao.select5();

            Object[] title = { "순위", "게임 ID", "티어", "승률", "총 플레이 수", "이긴 횟수" };
            Object[][] contents = new Object[list.size()][];
            for (int i = 0; i < list.size(); i++) {
               Object[] row = new Object[6];
               DTO dto = list.get(i);
               row[0] = (i + 1) + "위";
               row[1] = dto.getNickname();
               row[2] = dto.getTier();
               row[3] = String.format("%.2f", dto.getRate() * 100) + "%";
               row[4] = dto.getCount();
               row[5] = dto.getWin();
               contents[i] = row;
            }

            DefaultTableModel mod = new DefaultTableModel(contents, title) {
               public boolean isCellEditable(int rowIndex, int mColIndex) {
                  return false;
               }
            };
            table = new JTable(mod);
            table.setFont(new Font("굴림", Font.BOLD, 25));
            table.setRowHeight(50);
            table.setCellSelectionEnabled(true);
            table.getTableHeader().setReorderingAllowed(false);
            table.getTableHeader().setResizingAllowed(false);

            JScrollPane scrollPane = new JScrollPane();
            scrollPane.setViewportView(table);
            scrollPane.setBounds(12, 76, 975, 638);
            f.getContentPane().add(scrollPane);

            JOptionPane.showMessageDialog(null, "새로고침 되었습니다.");
         }
      });

      btnNewButton_1.setBounds(859, 22, 128, 41);
      f.getContentPane().add(btnNewButton_1);

      JLabel lblNewLabel_1 = new JLabel("검색 옵션");
      lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 30));
      lblNewLabel_1.setBounds(1034, 77, 144, 53);
      f.getContentPane().add(lblNewLabel_1);

      JButton btnNewButton = new JButton("티어별 분포 확인");
      btnNewButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            PieChartMain pie = new PieChartMain();
            pie.pie();
         }
      });
      btnNewButton.setBounds(999, 683, 205, 31);
      f.getContentPane().add(btnNewButton);

      DefaultListModel listModel = new DefaultListModel();
      for (String s : tier) {
         listModel.addElement(s);
      }
      list_1.setModel(listModel);

      JButton btnNewButton_2 = new JButton("확인");
      btnNewButton_2.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            String tier = (String) list_1.getSelectedValue();
            DAO dao = new DAO();
            ArrayList<DTO> list = dao.select6(tier);

            Object[] title = { "순위", "게임 ID", "승률", "총 플레이 수", "이긴 횟수" };
            Object[][] contents = new Object[list.size()][];
            for (int i = 0; i < list.size(); i++) {
               Object[] row = new Object[5];
               DTO dto = list.get(i);
               row[0] = (i + 1) + "위";
               row[1] = dto.getNickname();
               row[2] = String.format("%.2f", dto.getRate() * 100) + "%";
               row[3] = dto.getCount();
               row[4] = dto.getWin();
               contents[i] = row;
            }

            DefaultTableModel mod = new DefaultTableModel(contents, title) {
               public boolean isCellEditable(int rowIndex, int mColIndex) {
                  return false;
               }
            };
            table = new JTable(mod);
            table.setFont(new Font("굴림", Font.BOLD, 25));
            table.setRowHeight(50);
            table.setCellSelectionEnabled(true);
            table.getTableHeader().setReorderingAllowed(false);
            table.getTableHeader().setResizingAllowed(false);

            JScrollPane scrollPane = new JScrollPane();
            scrollPane.setViewportView(table);
            scrollPane.setBounds(12, 76, 975, 638);
            f.getContentPane().add(scrollPane);
         }
      });
      btnNewButton_2.setBounds(999, 463, 205, 31);
      f.getContentPane().add(btnNewButton_2);

      f.setVisible(true);
   }
}