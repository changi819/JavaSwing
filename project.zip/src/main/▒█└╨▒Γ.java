package main;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.mysql.jdbc.RowData;

import db.BbsDAO;
import db.BbsDTO;
import db.MemberDTO;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class 글읽기 {
   String id = MemberDTO.id;
   String pw = MemberDTO.pw; //MemberDTO에 static으로 지정된 id, pw값을 가져옴
   JFrame f = new JFrame();
   private JTextField t2;
   private JTextField t3;
   /**
    * @wbp.parser.entryPoint
    */
   public void read(int value) {
      BbsDAO dao = new BbsDAO();
//      count = dao.getLike(value);
//      int count1 =1;
      f.getContentPane().setBackground(new Color(102, 255, 255));
      f.setSize(600,600);
      f.getContentPane().setLayout(null);
      ArrayList<BbsDTO> list = dao.select();
      BbsDTO dto = list.get(value - 1); //(value-1 = num값)을 리스트에 넣어줌
      
      
      JLabel lblNewLabel = new JLabel("\uAE00\uC77D\uAE30");
      lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 25));
      lblNewLabel.setBounds(44, 36, 172, 48);
      f.getContentPane().add(lblNewLabel);
      
      JLabel lblNewLabel_1 = new JLabel("\uC81C\uBAA9:");
      lblNewLabel_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      lblNewLabel_1.setBounds(44, 128, 126, 58);
      f.getContentPane().add(lblNewLabel_1);
      
      JLabel lblNewLabel_1_1 = new JLabel("\uB0B4\uC6A9:");
      lblNewLabel_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      lblNewLabel_1_1.setBounds(44, 179, 126, 58);
      f.getContentPane().add(lblNewLabel_1_1);
      
      JButton b1 = new JButton("\uCDE8\uC18C");
      b1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            f.dispose();
         }
      });
      b1.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
      b1.setBounds(56, 482, 126, 58);
      f.getContentPane().add(b1);
      JLabel lblNewLabel_2 = new JLabel("\uC544\uC774\uB514:");
      lblNewLabel_2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      lblNewLabel_2.setBounds(44, 103, 107, 23);
      f.getContentPane().add(lblNewLabel_2);
      
      JButton b3 = new JButton("\uC218\uC815"); //수정하기
      b3.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            
            if (MemberDTO.id.equals(dto.getId())) { //로그인 한 id와 게시글에 저장된 id가 같다면
               JOptionPane.showMessageDialog(null, "게시글을 수정합니다.");
               글읽기 ad = new 글읽기();
               ad.adjust(value); //글수정 창 띄우기
               f.dispose();
            } else {
               JOptionPane.showMessageDialog(null, "아이디와 비밀번호를 확인해주세요.");
            }
            
            
         }
      });
      b3.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
      b3.setBounds(406, 482, 126, 58);
      f.getContentPane().add(b3);
      
      JButton b2 = new JButton("\uC0AD\uC81C"); //삭제하기
      b2.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            ArrayList<BbsDTO> list = dao.select();
            BbsDTO dto = list.get(value - 1); //value = num값
            BbsDAO dao = new BbsDAO();
            
            if (MemberDTO.id.equals(dto.getId())) { //로그인 한 id와 게시글에 저장된 id가 같다면
               System.out.println(dao.getDbNumber());
                  JOptionPane.showMessageDialog(null, "게시글을 삭제합니다.");
                  dao.delete(value);
                  f.dispose();         
            } else {
               JOptionPane.showMessageDialog(null, "아이디와 비밀번호를 확인해주세요.");
            }
         }
      });
      b2.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
      b2.setBounds(230, 482, 126, 58);
      f.getContentPane().add(b2);
      
      
      JLabel t1 = new JLabel("");
      t1.setFont(new Font("굴림", Font.PLAIN, 20));
      t1.setBounds(128, 103, 355, 23);
      f.getContentPane().add(t1);
      t1.setText(dto.id);
      
      t2 = new JTextField();
      t2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      t2.setColumns(10);
      t2.setBounds(128, 141, 383, 33);
      f.getContentPane().add(t2);
      t2.setText(dto.getSubject());
      t2.setEnabled(false); // 수정불가
      

      t3 = new JTextField();
      t3.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      t3.setBounds(128, 202, 383, 231);
      f.getContentPane().add(t3);
      t3.setColumns(10);
      t3.setText(dto.getContent()); //게시글에 저장된 id, subject, content 가져오기
      t3.setHorizontalAlignment(SwingConstants.LEFT); //content 내용을 왼쪽 정렬
      t3.setEnabled(false); // 수정불가
      
      f.setVisible(true);
         }
   
   //2. 게시글 글수정 UI(글수정을 할때) num의 위치인 value값을 사용하기 위해
   public void adjust(int value) { 
      
      f.getContentPane().setBackground(new Color(102, 255, 255));
      f.setSize(600,600);
      f.getContentPane().setLayout(null);
      JLabel lblNewLabel = new JLabel("\uAE00\uC4F0\uAE30");
      lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 25));
      lblNewLabel.setBounds(44, 36, 172, 48);
      f.getContentPane().add(lblNewLabel);
      
      JLabel lblNewLabel_1 = new JLabel("\uC81C\uBAA9:");
      lblNewLabel_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      lblNewLabel_1.setBounds(44, 128, 126, 58);
      f.getContentPane().add(lblNewLabel_1);
      
      t2 = new JTextField();
      t2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      t2.setColumns(10);
      t2.setBounds(128, 141, 383, 33);
      f.getContentPane().add(t2);
      
      JLabel lblNewLabel_1_1 = new JLabel("\uB0B4\uC6A9:");
      lblNewLabel_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      lblNewLabel_1_1.setBounds(44, 179, 126, 58);
      f.getContentPane().add(lblNewLabel_1_1);
      
      t3 = new JTextField();
      t3.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      t3.setBounds(128, 202, 383, 231);
      f.getContentPane().add(t3);
      t3.setColumns(10);
      t3.setHorizontalAlignment(SwingConstants.LEFT); //content 내용을 왼쪽 정렬
      
      JButton btnNewButton_1_1_1 = new JButton("\uC800\uC7A5");
      btnNewButton_1_1_1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            BbsDAO dao = new BbsDAO();
            String id = MemberDTO.id;
            String subject = t2.getText();
            String content = t3.getText();
            dao.update(subject, content, value);
            //입력값을 dto로 받아야함
            JOptionPane.showMessageDialog(null, "글이 게시되었습니다.");
            
            f.dispose();
            
         }
      });
   btnNewButton_1_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
   btnNewButton_1_1_1.setBounds(407, 441, 126, 58);
   f.getContentPane().add(btnNewButton_1_1_1);
   
   JButton btnNewButton_1_1_2 = new JButton("\uCDE8\uC18C");
   btnNewButton_1_1_2.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
         f.dispose();
      }
   });
   btnNewButton_1_1_2.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
   btnNewButton_1_1_2.setBounds(58, 441, 126, 58);
   f.getContentPane().add(btnNewButton_1_1_2);
   
   JLabel lblNewLabel_1_2 = new JLabel("\uC544\uC774\uB514:");
   lblNewLabel_1_2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
   lblNewLabel_1_2.setBounds(44, 77, 126, 58);
   f.getContentPane().add(lblNewLabel_1_2);
   
   JLabel t1 = new JLabel("");
   t1.setBounds(131, 94, 366, 23);
   f.getContentPane().add(t1);
   t1.setText(MemberDTO.id);
   
   
   f.setVisible(true);
}
}