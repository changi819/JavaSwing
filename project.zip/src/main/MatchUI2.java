package main;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JTextField;

import db.Crawling;
import db.DAO;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MatchUI2 {
   /**
    * @wbp.parser.entryPoint
    */

   public void match (String id, String nick, String tier, double rate) {
      
      JFrame f = new JFrame();
      f.getContentPane().setBackground(new Color(135, 206, 250));
      f.setSize(836, 600);
      f.getContentPane().setLayout(null);
      
      JScrollPane scrollPane = new JScrollPane();
      scrollPane.setBounds(12, 67, 325, 475);
      f.getContentPane().add(scrollPane);
      
      JList list = new JList();
      list.setFont(new Font("굴림", Font.PLAIN, 20));
      scrollPane.setViewportView(list);
      
      DefaultListModel listModel = new DefaultListModel();
        
        Crawling cr = new Crawling();
        ArrayList<String> name = cr.name();
        for (String s : name) {
           listModel.addElement(s);
        }
        
        list.setModel(listModel);
        
        String[] position = { "Top", "Bottom" ,"Mid", "Support", "Jungle" };
        
      JScrollPane scrollPane_1 = new JScrollPane();
      scrollPane_1.setBounds(338, 67, 325, 475);
      f.getContentPane().add(scrollPane_1);
      
      JList list_1 = new JList();
      list_1.setFont(new Font("굴림", Font.PLAIN, 20));
      scrollPane_1.setViewportView(list_1);
      
      DefaultListModel listModel_1 = new DefaultListModel();
      for (String s : position) {
              listModel_1.addElement(s);
           }
           
        list_1.setModel(listModel_1);
      
      JLabel lblNewLabel = new JLabel("주 챔피언");
      lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 25));
      lblNewLabel.setBounds(12, 10, 159, 47);
      f.getContentPane().add(lblNewLabel);
      
      JLabel lblNewLabel_1 = new JLabel("포지션");
      lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 25));
      lblNewLabel_1.setBounds(338, 10, 159, 47);
      f.getContentPane().add(lblNewLabel_1);
      
      JButton btnNewButton = new JButton("등록");
      btnNewButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            String champ = String.valueOf(list.getSelectedValue());
            String position = String.valueOf(list_1.getSelectedValue());
            
            DAO dao = new DAO();
            dao.insert(id, nick, tier, rate, champ , position);
            JOptionPane.showMessageDialog(null, "등록되었습니다.");
            f.dispose();
         }
      });
      
      
      
      btnNewButton.setFont(new Font("굴림", Font.PLAIN, 25));
      btnNewButton.setBounds(675, 495, 135, 47);
      f.getContentPane().add(btnNewButton);
      
      
      f.setVisible(true);
   }
   
}