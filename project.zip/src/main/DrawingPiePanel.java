package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;

import db.DAO;
import db.DTO;

class DrawingPiePanel extends JPanel {

   public void paint(Graphics g) {
      DAO dao = new DAO();
      ArrayList<DTO> list = dao.select7();
      int num1 = list.get(0).getCount();
      int num2 = list.get(1).getCount();
      int num3 = list.get(2).getCount();
      int num4 = list.get(3).getCount();
      int num5 = list.get(4).getCount();
      int num6 = list.get(5).getCount();
      int num7 = list.get(6).getCount();
      int num8 = list.get(7).getCount();
      int num9 = list.get(8).getCount(); //각 티어 별 카운트를 변수에 지정

      g.clearRect(0, 0, getWidth(), getHeight());
      // 값이 입력되지않았으면 return;
      if ((num1 < 0) || (num2 < 0) || (num3 < 0) || (num4 < 0) || (num5 < 0) || (num6 < 0) || (num7 < 0) || (num8 < 0) || (num9 < 0))
         return;
      
      int total = num1 + num2 + num3 + num4 + num5 + num6 + num7 + num8 + num9;
      if (total == 0)
         return;
      
      int arc1 = (int) 360.0 * num1 / total;
      int arc2 = (int) 360.0 * num2 / total;
      int arc3 = (int) 360.0 * num3 / total;
      int arc4 = (int) 360.0 * num4 / total;
      int arc5 = (int) 360.0 * num5 / total;
      int arc6 = (int) 360.0 * num6 / total;
      int arc7 = (int) 360.0 * num7 / total;
      int arc8 = (int) 360.0 * num8 / total;
      g.setColor(Color.YELLOW);
      g.fillArc(50, 20, 500, 500, 0, arc1);// 각 티어별 카운트를 변수 지정 후 전체 total 에서 차지하는 비중을 각으로 변환
                                           //(x축,y축,반지름,반지름,시작각,끝각) - 원호를 그림
      g.setColor(Color.RED);
      g.fillArc(50, 20, 500, 500, arc1, arc2);
      g.setColor(Color.BLUE);
      g.fillArc(50, 20, 500, 500, arc1 + arc2 + arc3, arc4);
      g.setColor(Color.GREEN);
      g.fillArc(50, 20, 500, 500, arc1 + arc2 + arc3 + arc4, arc5);
      g.setColor(Color.PINK);
      g.fillArc(50, 20, 500, 500, arc1 + arc2 + arc3 + arc4 + arc5, arc6);
      g.setColor(Color.CYAN);
      g.fillArc(50, 20, 500, 500, arc1 + arc2 + arc3 + arc4 + arc5 + arc6, arc7);
      g.setColor(Color.GRAY);
      g.fillArc(50, 20, 500, 500, arc1 + arc2 + arc3 + arc4 + arc5 + arc6 + arc7, arc8);
      g.setColor(Color.DARK_GRAY);
      g.fillArc(50, 20, 500, 500, arc1 + arc2 + arc3 + arc4 + arc5 + arc6 + arc7 + arc8,
            360 - (arc1 + arc2 + arc3 + arc4 + arc5 + arc6 + arc7 + arc8));
      
      g.setColor(Color.BLACK);
      g.setFont(new Font("굴림체", Font.PLAIN, 25));
      g.drawString(list.get(0).getTier() + "(노랑)" + " : " + String.format("%.2f", (num1 / (double)total) * 100) + "%", 600, 100);
      g.drawString(list.get(1).getTier() + "(빨강)" + " : " + String.format("%.2f", (num2 / (double)total) * 100) + "%", 600, 130);
      g.drawString(list.get(2).getTier() + "(파랑)" + " : " + String.format("%.2f", (num3 / (double)total) * 100) + "%", 600, 160);
      g.drawString(list.get(3).getTier() + "(초록)" + " : " + String.format("%.2f", (num4 / (double)total) * 100) + "%", 600, 190);
      g.drawString(list.get(4).getTier() + "(분홍)" + " : " + String.format("%.2f", (num5 / (double)total) * 100) + "%", 600, 220);
      g.drawString(list.get(5).getTier() + "(하늘)" + " : " + String.format("%.2f", (num6 / (double)total) * 100)  + "%", 600, 250);
      g.drawString(list.get(6).getTier() + "(회색)" + " : " + String.format("%.2f", (num7 / (double)total) * 100)  + "%", 600, 280);
      g.drawString(list.get(7).getTier() + "(검정)" + " : " + String.format("%.2f", (num8 / (double)total) * 100) + "%", 600, 310);
      g.drawString(list.get(8).getTier() + "(흰색)" + " : " + String.format("%.2f", (num9 / (double)total) * 100)  + "%", 600, 340);
   }

}