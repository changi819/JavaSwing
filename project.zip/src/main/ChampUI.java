package main;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

import db.Crawling;
import db.DAO;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JList;

public class ChampUI {
   private static JTextField textField;
   public void ChampMain() {
      JFrame f = new JFrame();
      f.getContentPane().setBackground(new Color(100, 149, 237));
      f.setSize(754,555);
      f.getContentPane().setLayout(null);

      JLabel lblNewLabel = new JLabel("    \uCC54\uD53C\uC5B8\uBCC4 \uD1B5\uACC4");
      lblNewLabel.setBounds(12, 10, 161, 34);
      lblNewLabel.setFont(new Font("굴림", Font.BOLD, 20));
      f.getContentPane().add(lblNewLabel);
      
      JScrollPane scrollPane = new JScrollPane();
      scrollPane.setBounds(12, 54, 513, 454);
      f.getContentPane().add(scrollPane);
      
      JList list = new JList();
      list.setFont(new Font("굴림", Font.PLAIN, 25));
      scrollPane.setViewportView(list);
      DefaultListModel listModel = new DefaultListModel();

      Crawling cr = new Crawling();
      ArrayList<String> name = cr.name();
      
      for (String s : name) {
         listModel.addElement(s);
      }
      MouseListener mouseListener = new MouseAdapter() {
           public void mouseClicked(MouseEvent e) {
               if (e.getClickCount() == 2) {
                   ChampUI2 ui = new ChampUI2();
                   ui.champ((String)list.getSelectedValue());
                }
           }
      };
      list.addMouseListener(mouseListener);
      list.setModel(listModel);
      
      JButton btnNewButton = new JButton("이름 순서로 보기");
      btnNewButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            JList list = new JList();
            list.setFont(new Font("굴림", Font.PLAIN, 25));
            scrollPane.setViewportView(list);
            DefaultListModel listModel = new DefaultListModel();
            
            Crawling cr = new Crawling();
            ArrayList<String> name = cr.name(); 
            for (String s : name) {            
               listModel.addElement(s);
            }                 // 크롤링한 챔피언 이름목록 가져와서 list에 출력
            MouseListener mouseListener = new MouseAdapter() { 
                 public void mouseClicked(MouseEvent e) {
                     if (e.getClickCount() == 2) {
                         ChampUI2 ui = new ChampUI2();
                         ui.champ((String)list.getSelectedValue());
                      }
                 }             //더블 클릭시 챔피언별 플레이된 게임 결과 출력
            };
            list.addMouseListener(mouseListener);
            list.setModel(listModel);
         }
      });
      btnNewButton.setBounds(537, 62, 191, 41);
      f.getContentPane().add(btnNewButton);
      
      JButton btnTop = new JButton("승률 TOP 10");
      btnTop.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            JList list = new JList();
            list.setFont(new Font("굴림", Font.PLAIN, 25));
            scrollPane.setViewportView(list);
            DefaultListModel listModel = new DefaultListModel();
            
            DAO dao = new DAO();
            String[] name = dao.select2();
            for (int i = 0; i < 10; i++) {
               listModel.addElement(name[i]);
            }
            MouseListener mouseListener = new MouseAdapter() {
                 public void mouseClicked(MouseEvent e) {
                     if (e.getClickCount() == 2) {
                         ChampUI2 ui = new ChampUI2();
                         ui.champ((String)list.getSelectedValue());
                      }
                 }
            };
            list.addMouseListener(mouseListener);
            list.setModel(listModel);
         }
      });
      btnTop.setBounds(537, 167, 191, 41);
      f.getContentPane().add(btnTop);
      
      textField = new JTextField();
      textField.setFont(new Font("굴림", Font.PLAIN, 20));
      textField.setBounds(537, 413, 191, 41);
      f.getContentPane().add(textField);
      textField.setColumns(10);
      
      JLabel lblNewLabel_1 = new JLabel("이름으로 검색");
      lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 20));
      lblNewLabel_1.setBounds(537, 369, 191, 34);
      f.getContentPane().add(lblNewLabel_1);
      
      JButton btnNewButton_1 = new JButton("확인");
      btnNewButton_1.setBounds(637, 464, 91, 44);
      btnNewButton_1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            String name = textField.getText();
            ChampUI2 ui = new ChampUI2();
            ui.champ(name);
         }
      });
      f.getContentPane().add(btnNewButton_1);
      
      JButton btnNewButton_2 = new JButton("픽률 순서로 보기");
      btnNewButton_2.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            JList list = new JList();
            list.setFont(new Font("굴림", Font.PLAIN, 25));
            scrollPane.setViewportView(list);
            DefaultListModel listModel = new DefaultListModel();
            
            DAO dao = new DAO();
            String[] name = dao.select3();
            for (int i = 0; i < 148; i++) {
               listModel.addElement(name[i]);
            }
            MouseListener mouseListener = new MouseAdapter() {
                 public void mouseClicked(MouseEvent e) {
                     if (e.getClickCount() == 2) {
                         ChampUI2 ui = new ChampUI2();
                         ui.champ((String)list.getSelectedValue());
                      }
                 }
            };
            list.addMouseListener(mouseListener);
            list.setModel(listModel);
         }
      });
      btnNewButton_2.setBounds(537, 113, 191, 41);
      f.getContentPane().add(btnNewButton_2);
      f.setVisible(true);
   }
}