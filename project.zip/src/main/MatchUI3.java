package main;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import db.DTO;


public class MatchUI3 {
   private JTable table;
   /**
    * @wbp.parser.entryPoint
    */
   public void ui(ArrayList<DTO> list) {
      JFrame f = new JFrame();
      f.setSize(668, 370);
      
      Object[] title = {"게임 ID", "티어", "승률", "주 챔피언", "포지션"};
      Object[][] contents = new Object[list.size()][];
      for (int i = 0; i < list.size(); i++) {
         Object[] row = new Object[5];
         DTO dto = list.get(i); 
         row[0] = dto.getNickname();
         row[1] = dto.getTier();
         row[2] = dto.getRate() * 100 + "%";
         row[3] = dto.getChamp();
         row[4] = dto.getPosition();
         contents[i] = row;
      }
      DefaultTableModel mod = new DefaultTableModel(contents, title) {
         public boolean isCellEditable(int rowIndex, int mColIndex) {
            return false;
         }
      };
      table = new JTable(mod);
      table.setFont(new Font("굴림", Font.BOLD, 25));
      table.setRowHeight(50);
      table.setCellSelectionEnabled(true);
      table.getTableHeader().setReorderingAllowed(false);
      table.getTableHeader().setResizingAllowed(false);
        
        JScrollPane scrollPane = new JScrollPane();
        f.getContentPane().add(scrollPane, BorderLayout.CENTER);
        scrollPane.setViewportView(table);
      
      
      f.setVisible(true);
   }
}