package main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.tools.DocumentationTool.Location;

import db.BbsDAO;
import db.BbsDTO;
import db.MemberDTO;

import java.awt.Font;

public class Community {
	private static JTable table;
	private static JTable table_1;
	BbsDTO dto = new BbsDTO();

	/**
	 * @wbp.parser.entryPoint
	 */
	public void community() {
		JFrame f = new JFrame();
		f.setSize(700, 700);
		f.getContentPane().setBackground(new Color(102, 255, 255));
		f.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(29, 37, 629, 519);
		f.getContentPane().add(scrollPane);
		
		BbsDAO dao = new BbsDAO();
		
		ArrayList<BbsDTO> list = dao.select(); 
		System.out.println("목록의 개수는 " + list.size());
		Object[] title = { "게시글 번호", "아이디", "제목" };
		Object[][] contents = new Object[list.size()][]; //JScrollPane에 2차원 배열을 넣음
		for (int i = 0; i < list.size(); i++) {
			dto = list.get(i); //dto에 list값을 각각 넣음(행)
			Object[] row = new Object[3]; //열의 개수가 3개
			row[0] = i + 1; //1번째 열 num
			System.out.println(row[0]);
			row[1] = dto.getId(); //2번째 열 id
			row[2] = dto.getSubject(); //3번째 열 subject
			contents[i] = row; //열의 내용을 각각 넣음
			
		}
		
		DefaultTableModel mod = new DefaultTableModel(contents, title) { //테이블데이터모델의 클래스를 선언 
	        public boolean isCellEditable(int rowIndex, int mColIndex) {
	                return false; //내용 수정 불가
	            }
	        };	
	      
		JTable table_1 = new JTable(mod);
		scrollPane.setViewportView(table_1);
		table_1.getTableHeader().setReorderingAllowed(false); //테이블 컬럼 이동 불가
        table_1.getTableHeader().setResizingAllowed(false); //테이블 컬럼 크기 조절 불가(고정)
        table_1.addMouseListener(new MouseAdapter () {

        	public void mouseClicked(MouseEvent e) {

        	if (e.getClickCount() == 2) {  // 더블클릭
        		int row = table_1.getSelectedRow(); //table_1의 1번째 열을 가져옴
        		int col = 0;
        		int value = Integer.parseInt(String.valueOf(table_1.getValueAt(row, col)));
        		System.out.println(table_1.getValueAt(row, col));
        		글읽기 read = new 글읽기();
        		read.read(value);
        		}
        	}

        	});
		JButton b1 = new JButton("\uAE00\uC4F0\uAE30");
		b1.setFont(new Font("굴림", Font.PLAIN, 30));
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				글쓰기 wr = new 글쓰기();
				wr.write();
			}
		});
		
		b1.setBounds(39, 566, 266, 72);
		f.getContentPane().add(b1);		
		
		JButton b2 = new JButton("\uC0C8\uB85C\uACE0\uCE68");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BbsDAO dao = new BbsDAO();
				
				ArrayList<BbsDTO> list = dao.select(); //
				System.out.println("목록의 개수는 " + list.size());
				Object[] title = { "게시글 번호", "아이디", "제목" };
				Object[][] contents = new Object[list.size()][];
				for (int i = 0; i < list.size(); i++) {
					BbsDTO dto = list.get(i);
					Object[] row = new Object[3];
					row[0] = i + 1;
					row[1] = dto.getId();
					row[2] = dto.getSubject();

					contents[i] = row;
				}
				
				DefaultTableModel mod = new DefaultTableModel(contents, title) { //테이블만들기 
			        public boolean isCellEditable(int rowIndex, int mColIndex) { //바꾸지 못하게 
			                return false;
			            }
			        };	
				JTable table_1 = new JTable(mod);
				scrollPane.setViewportView(table_1);
				table_1.getTableHeader().setReorderingAllowed(false);// 이동불가
		        table_1.getTableHeader().setResizingAllowed(false);//크기조정불가
				
		        table_1.addMouseListener(new MouseAdapter () {

		        	public void mouseClicked(MouseEvent e) {

		        	if (e.getClickCount() == 2) {  // 더블클릭
		        		int row = table_1.getSelectedRow();
		        		int col = 0;
		        		int value = Integer.parseInt(String.valueOf(table_1.getValueAt(row, col)));
		        		글읽기 read = new 글읽기();
		        		read.read(value); //Value는 Num값
		        		}
		        	}

		        	});
			}
		});
		b2.setFont(new Font("굴림", Font.PLAIN, 30));
		b2.setBounds(378, 566, 266, 72);
		f.getContentPane().add(b2);
		System.out.println(MemberDTO.id);
		f.setVisible(true);
	}
}
