package main;

import javax.swing.JFrame;
import javax.swing.JTextField;

import db.MemberDTO;
import db.ScoreDTO;
import db.Dbprocess;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

public class ScoreInsert {
	private static JTextField tWinLose;
	private static JTextField tChamp;
	private static JTextField tMurder;
	private static JTextField tDeath;
	private static JTextField tAssi;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void insertData(ScoreDTO sdto) {
		// TODO Auto-generated method stub
		Dbprocess db = new Dbprocess();
		JFrame f = new JFrame();
		f.getContentPane().setBackground(new Color(100, 149, 237));
		f.setTitle("전적 데이터 입력창");
		f.setSize(736, 514);
		f.getContentPane().setLayout(null);

		tWinLose = new JTextField();
		tWinLose.setBounds(325, 10, 210, 57);
		f.getContentPane().add(tWinLose);
		tWinLose.setColumns(10);

		tChamp = new JTextField();
		tChamp.setColumns(10);
		tChamp.setBounds(325, 77, 210, 43);
		f.getContentPane().add(tChamp);

		tMurder = new JTextField();
		tMurder.setColumns(10);
		tMurder.setBounds(325, 183, 210, 43);
		f.getContentPane().add(tMurder);

		tDeath = new JTextField();
		tDeath.setColumns(10);
		tDeath.setBounds(325, 236, 210, 43);
		f.getContentPane().add(tDeath);

		tAssi = new JTextField();
		tAssi.setColumns(10);
		tAssi.setBounds(325, 289, 210, 43);
		f.getContentPane().add(tAssi);

		JLabel lblNewLabel = new JLabel("승/패 결과");
		lblNewLabel.setFont(new Font("휴먼모음T", Font.PLAIN, 30));
		lblNewLabel.setBounds(180, 10, 133, 63);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("챔피언");
		lblNewLabel_1.setFont(new Font("휴먼모음T", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(237, 58, 94, 73);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_3 = new JLabel("킬");
		lblNewLabel_3.setFont(new Font("휴먼모음T", Font.PLAIN, 30));
		lblNewLabel_3.setBounds(286, 169, 74, 63);
		f.getContentPane().add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("데스");
		lblNewLabel_4.setFont(new Font("휴먼모음T", Font.PLAIN, 30));
		lblNewLabel_4.setBounds(260, 228, 101, 57);
		f.getContentPane().add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("어시스트");
		lblNewLabel_5.setFont(new Font("휴먼모음T", Font.PLAIN, 30));
		lblNewLabel_5.setBounds(212, 281, 148, 73);
		f.getContentPane().add(lblNewLabel_5);

		//추가버튼
		JButton btnInsert = new JButton("추가");
		btnInsert.setFont(new Font("휴먼모음T", Font.PLAIN, 40));
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { //추가버튼을 누르면
				String result = tWinLose.getText();		//텍스트필드에 값 저장
//				String tier = tTier.getText();
				String champ = tChamp.getText();
				int murder = Integer.parseInt(tMurder.getText());
				int death = Integer.parseInt(tDeath.getText());
				int assi = Integer.parseInt(tAssi.getText());
				//scoreDTO로 저장
				sdto.setResult(result);
//				sdto.setTier(tier);
				sdto.setChamp(champ);
				sdto.setMurder(murder);
				sdto.setDeath(death);
				sdto.setAssist(assi);
				//db.insert 메소드 호출
				db.insert(sdto);
				f.dispose();
			}
		});
		btnInsert.setBounds(260, 392, 210, 73);
		f.getContentPane().add(btnInsert);

		f.setVisible(true);
	}
}
