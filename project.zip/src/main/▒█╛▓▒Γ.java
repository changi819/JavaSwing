package main;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import db.BbsDAO;
import db.MemberDTO;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class 글쓰기 {
   private static JTextField t2;
   private static JTextField t3;
   String id = MemberDTO.id;
   String pw = MemberDTO.pw; //MemberDTO에서 static지정한 id, pw값을 가져옴
   JFrame f = new JFrame(); //글쓰기, 글수정 시 JFrame공유함으로 전역변수로 지정

   
   /**
    * @wbp.parser.entryPoint
    */
   // 게시글 글쓰기 UI(글쓰기를 할때)
   public void write() { 
      f.getContentPane().setBackground(new Color(102, 255, 255));
      f.setSize(600,600);
      f.getContentPane().setLayout(null);
      JLabel Title = new JLabel("\uAE00\uC4F0\uAE30");
      Title.setFont(new Font("맑은 고딕", Font.BOLD, 25));
      Title.setBounds(44, 36, 172, 48);
      f.getContentPane().add(Title); //글쓰기 타이틀
      
      JLabel lblNewLabel_1 = new JLabel("\uC81C\uBAA9:");
      lblNewLabel_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      lblNewLabel_1.setBounds(44, 128, 126, 58);
      f.getContentPane().add(lblNewLabel_1);
      
      t2 = new JTextField();
      t2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      t2.setColumns(10);
      t2.setBounds(131, 145, 377, 41);
      f.getContentPane().add(t2);
      
      JLabel lblNewLabel_1_1 = new JLabel("\uB0B4\uC6A9:");
      lblNewLabel_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      lblNewLabel_1_1.setBounds(44, 179, 126, 58);
      f.getContentPane().add(lblNewLabel_1_1);
      
      t3 = new JTextField();
      t3.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      t3.setColumns(10);
      t3.setBounds(131, 212, 377, 206);
      f.getContentPane().add(t3);
      
      
      JButton btnNewButton_1_1_1 = new JButton("\uC800\uC7A5");
      btnNewButton_1_1_1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            BbsDAO dao = new BbsDAO(); //dao를 생성
            String id = MemberDTO.id; //id에 MemberDTO에 static으로 지정한 id(현재 로그인한 id)가져옴
            String subject = t2.getText();
            String content = t3.getText();
            //subject, content 각각 입력
            
            dao.insert(id, subject, content);
            //dao.insert에 id, subject, content 각각 입력
            
            JOptionPane.showMessageDialog(null, "글이 게시되었습니다.");
            
            f.dispose();
            
         }
      });
      
      
            
      btnNewButton_1_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
      btnNewButton_1_1_1.setBounds(407, 441, 126, 58);
      f.getContentPane().add(btnNewButton_1_1_1);
      
      JButton btnNewButton_1_1_2 = new JButton("\uCDE8\uC18C");
      btnNewButton_1_1_2.addActionListener(new ActionListener() { //취소하기
         public void actionPerformed(ActionEvent e) {
            f.dispose();
         }
      });
      btnNewButton_1_1_2.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
      btnNewButton_1_1_2.setBounds(58, 441, 126, 58);
      f.getContentPane().add(btnNewButton_1_1_2);
      
      JLabel lblNewLabel_1_2 = new JLabel("\uC544\uC774\uB514:");
      lblNewLabel_1_2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
      lblNewLabel_1_2.setBounds(44, 83, 126, 58);
      f.getContentPane().add(lblNewLabel_1_2);
      
      JLabel t1 = new JLabel("");
      t1.setFont(new Font("굴림", Font.PLAIN, 20));
      t1.setBounds(131, 94, 377, 36);
      f.getContentPane().add(t1);
      t1.setText(MemberDTO.id); //static으로 지정한 MemberDTO의 id(현재 로그인한 id)를 가져옴
      
      
      f.setVisible(true);
         }
   
   
}