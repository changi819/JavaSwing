package main;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import db.Crawling;
import db.DAO;
import db.DTO;

import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChampUI2 {
   private static JLabel lblNewLabel;
   private JTable table;

   /**
    * @wbp.parser.entryPoint
    */
   public void champ(String champ) {
      
      Crawling cr = new Crawling();
      ArrayList<String> name = cr.name();
      JFrame f = new JFrame();
      f.setSize(1238, 760);
      f.getContentPane().setBackground(new Color(100, 149, 237));
      f.getContentPane().setLayout(null);

      DAO dao = new DAO();
      ArrayList<DTO> list = dao.select(champ);
      
      Object[] title = {"게임 ID", "승/패", "티어", "KILL", "DEATH", "ASSIST"};
      Object[][] contents = new Object[list.size()][];
      for (int i = 0; i < list.size(); i++) {
         Object[] row = new Object[6];
         DTO dto = list.get(i);
         row[0] = dto.getNickname();
         row[1] = dto.getResult();
         row[2] = dto.getTier();
         row[3] = dto.getKill();
         row[4] = dto.getDeath();
         row[5] = dto.getAssist();
         contents[i] = row;  // 이 챔피언으로 플레이한 게임 결과 출력
      }
      
      int i = 0;
      for (int j = 0; j < list.size(); j++) {
         if (contents[j][1].equals("Victory")) {
            i ++;
         }
      }
      
      double rate = ( i / (double)list.size() ) * 100;
      lblNewLabel = new JLabel("l");
      lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 25));
      lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
      lblNewLabel.setBounds(12, 10, 207, 60);
      f.getContentPane().add(lblNewLabel);
      
      for (Object s : name) {
         if (champ.equals(s)) {
            String name2 = (String)s;
            lblNewLabel.setText(name2);
         }
      }
      
      DefaultTableModel mod = new DefaultTableModel(contents, title) {
         public boolean isCellEditable(int rowIndex, int mColIndex) {
            return false;
         }
      };
      table = new JTable(mod);
      table.setFont(new Font("굴림", Font.BOLD, 25));
      table.setRowHeight(50);
      table.setCellSelectionEnabled(true);
      table.getTableHeader().setReorderingAllowed(false);
      table.getTableHeader().setResizingAllowed(false);
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setViewportView(table);
      scrollPane.setBounds(12, 80, 1200, 633);
      f.getContentPane().add(scrollPane);
      
      JLabel lblNewLabel_1 = new JLabel("l");
      lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
      lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 25));
      lblNewLabel_1.setBounds(561, 10, 651, 60);
      f.getContentPane().add(lblNewLabel_1);
      
      lblNewLabel_1.setText("총 플레이 수 : " + list.size() + "회,   승리 횟수 : " + i + "회,   승률 : " + String.format("%.2f", rate) + "%");
      
      JButton btnNewButton = new JButton("새로고침");
      btnNewButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            DAO dao = new DAO();
            ArrayList<DTO> list = dao.select(champ);
            
            Object[] title = {"게임 ID", "승/패", "티어", "KILL", "DEATH", "ASSIST"};
            Object[][] contents = new Object[list.size()][];
            for (int i = 0; i < list.size(); i++) {
               Object[] row = new Object[6];
               DTO dto = list.get(i);
               row[0] = dto.getNickname();
               row[1] = dto.getResult();
               row[2] = dto.getTier();
               row[3] = dto.getKill();
               row[4] = dto.getDeath();
               row[5] = dto.getAssist();
               contents[i] = row;
            }

            DefaultTableModel mod = new DefaultTableModel(contents, title) {
               public boolean isCellEditable(int rowIndex, int mColIndex) {
                  return false;
               }
            };
            table = new JTable(mod);
            table.setFont(new Font("굴림", Font.BOLD, 25));
            table.setRowHeight(50);
            table.setCellSelectionEnabled(true);
            table.getTableHeader().setReorderingAllowed(false);
            table.getTableHeader().setResizingAllowed(false);
              
              JScrollPane scrollPane = new JScrollPane();
              scrollPane.setViewportView(table);
            scrollPane.setBounds(12, 80, 1200, 633);
            f.getContentPane().add(scrollPane);
            JOptionPane.showMessageDialog(null, "새로고침 되었습니다.");
         }
      });
      btnNewButton.setBounds(231, 20, 142, 39);
      f.getContentPane().add(btnNewButton);
 
      f.setVisible(true);
      
   }
}