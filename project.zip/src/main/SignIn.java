package main;

import javax.swing.JFrame;
import javax.swing.JTextField;

import db.MemberDAO;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class SignIn {

	private static JTextField t1;
	private static JTextField t2;
	private static JTextField t3;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void signIn() {
		JFrame f = new JFrame();

		f.getContentPane().setBackground(new Color(51, 153, 255));
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);

		t1 = new JTextField();
		t1.setFont(new Font("굴림", Font.PLAIN, 20));
		t1.setBounds(140, 106, 190, 23);
		f.getContentPane().add(t1);
		t1.setColumns(10);

		JLabel lblNewLabel = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 25));
		lblNewLabel.setBounds(28, 34, 126, 41);
		f.getContentPane().add(lblNewLabel);

		JButton b2 = new JButton("\uAC00\uC785\uD558\uAE30");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = t1.getText();
				String pw = t2.getText();
				String nickname = t3.getText();
				MemberDAO dao = new MemberDAO();
				boolean result = dao.check(id);
				if (result == true) {// 아이디가 중복될때
					JOptionPane.showMessageDialog(null, "아이디 중복버튼을 확인해주세요.");
					t1.setText("");
					t2.setText("");
					t3.setText("");
				} else {
					if (id.equals("")) {
						JOptionPane.showMessageDialog(null, "아이디를 입력해주세요.");
					} else if (pw.equals("")) {
						JOptionPane.showMessageDialog(null, "비밀번호를 입력해주세요.");
					} else if (nickname.equals("")) {
						JOptionPane.showMessageDialog(null, "게임 닉네임을 입력해주세요.");
					} else {
						JOptionPane.showMessageDialog(null, "회원가입이 완료되었습니다.");

						dao.insert(id, pw, nickname);
						f.dispose();
					}
				}
			}

		});
		b2.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
		b2.setBounds(268, 291, 152, 67);
		f.getContentPane().add(b2);

		JLabel lblNewLabel_1 = new JLabel("\uC544\uC774\uB514:");
		lblNewLabel_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(28, 88, 126, 58);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("\uBE44\uBC00\uBC88\uD638:");
		lblNewLabel_2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(28, 129, 97, 58);
		f.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("\uAC8C\uC784\uC544\uC774\uB514:");
		lblNewLabel_3.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(28, 184, 126, 41);
		f.getContentPane().add(lblNewLabel_3);

		t2 = new JTextField();
		t2.setFont(new Font("굴림", Font.PLAIN, 20));
		t2.setColumns(10);
		t2.setBounds(140, 146, 190, 23);
		f.getContentPane().add(t2);

		t3 = new JTextField();
		t3.setFont(new Font("굴림", Font.PLAIN, 20));
		t3.setColumns(10);
		t3.setBounds(140, 192, 190, 23);
		f.getContentPane().add(t3);

		JButton b1 = new JButton("\uCDE8\uC18C"); //취소하기
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		b1.setFont(new Font("맑은 고딕", Font.PLAIN, 25));
		b1.setBounds(61, 291, 152, 67);
		f.getContentPane().add(b1);

		JButton btnNewButton = new JButton("\uC911\uBCF5 \uD655\uC778");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MemberDAO dao = new MemberDAO();

				String id = t1.getText();
				boolean result = dao.check(id);

				if (result == true) {
					JOptionPane.showMessageDialog(null, "중복된 아이디가 있습니다.");
					t1.setText("");

				} else {
					JOptionPane.showMessageDialog(null, "중복된 아이디가 없습니다.");
					int use = JOptionPane.showConfirmDialog(null, "이 아이디를 사용하시겠습니까?", "아이디 확인",
							JOptionPane.YES_NO_OPTION);
					if (use == JOptionPane.CLOSED_OPTION) {
						// 사용자가 "예", "아니오"의 선택 없이 다이얼로그 창을 닫은 경우
						t1.setText("");
					} else if (use == JOptionPane.NO_OPTION) {
						// 사용자가 "아니오"를 선택한 경우
						t1.setText("");
					} else {
						// 사용자가 "예"를 선택한 경우
						t1.getText();
					}
				}
			}
		});
		btnNewButton.setBounds(352, 106, 97, 23);
		f.getContentPane().add(btnNewButton);
		f.setVisible(true);
	}
}