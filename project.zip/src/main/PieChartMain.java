package main;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PieChartMain {
   public void pie() {
   JFrame frame = new JFrame("티어별 분포");
   frame.setLocation(400, 200);
   frame.setPreferredSize(new Dimension(1000, 600));
   
   Container contentPane = frame.getContentPane();
   DrawingPiePanel drawingPanel = new DrawingPiePanel();
   contentPane.add(drawingPanel, BorderLayout.CENTER);
   
   JPanel controlPanel = new JPanel();
   contentPane.add(controlPanel,BorderLayout.SOUTH);
 
   frame.pack();
   frame.setVisible(true);
   }
}