package main;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;

import db.ScoreDTO;
import db.Dbprocess;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;

public class Search {

	/**
	 * @wbp.parser.entryPoint
	 */
	public void searchWindow() {
		// TODO Auto-generated method stub
		JFrame f = new JFrame();
		Dbprocess db = new Dbprocess();
		f.setSize(870, 527);
		f.getContentPane().setBackground(new Color(100, 149, 237));
		f.setTitle("\uBA54\uC778");
		
		f.getContentPane().setLayout(null);
		
		JTextField t_search = new JTextField();
		t_search.setFont(new Font("굴림", Font.PLAIN, 25));
		t_search.setText("");
		t_search.setBounds(404, 417, 199, 61);
		f.getContentPane().add(t_search);
		t_search.setColumns(10);
		
		JButton btn_search = new JButton("\uAC80\uC0C9");		//검색버튼 
		btn_search.setFont(new Font("휴먼모음T", Font.PLAIN, 25));
		btn_search.setForeground(new Color(0, 0, 0));
		btn_search.setBackground(new Color(100, 149, 237));
		btn_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){			//게임아이디 검색버튼을 눌렀을때
				ScoreDTO sdto = new ScoreDTO();					//ScoreDTO sdto 생성
				String nickname=t_search.getText();				//nickname에 텍스트필드값을 넣음
				sdto.setNickname(nickname);						//스코어DTO에 닉네임을 방금받은값으로 설정
				sdto=db.searchNick(sdto);							//dbprocess에 searchnick실행
				Score s = new Score();
				s.scoreMain(sdto); // 점수메인화면 띄우기
			}
		});
		btn_search.setBounds(629, 418, 168, 61);
		f.getContentPane().add(btn_search);
		
		JButton btn_champ = new JButton("\uCC54\uD53C\uC5B8");
		btn_champ.setFont(new Font("휴먼모음T", Font.PLAIN, 25));
		btn_champ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChampUI champui = new ChampUI();
				champui.ChampMain();
			}
		});
		btn_champ.setForeground(new Color(0, 0, 0));
		btn_champ.setBackground(new Color(100, 149, 237));
		btn_champ.setBounds(64, 10, 168, 61);
		f.getContentPane().add(btn_champ);
		
		JButton btn_rank = new JButton("\uB7AD\uD0B9");
		btn_rank.setFont(new Font("휴먼모음T", Font.PLAIN, 25));
		btn_rank.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RankingUI rankui = new RankingUI();
				rankui.RankingMain();
			}
		});
		btn_rank.setForeground(new Color(0, 0, 0));
		btn_rank.setBackground(new Color(100, 149, 237));
		btn_rank.setBounds(255, 10, 168, 61);
		f.getContentPane().add(btn_rank);
		
		JButton btn_comu = new JButton("\uCEE4\uBBA4\uB2C8\uD2F0");
		btn_comu.setFont(new Font("휴먼모음T", Font.PLAIN, 25));
		btn_comu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Community comu = new Community();						
				comu.community();
			}
		});
		btn_comu.setForeground(new Color(0, 0, 0));
		btn_comu.setBackground(new Color(100, 149, 237));
		btn_comu.setBounds(629, 10, 168, 61);
		f.getContentPane().add(btn_comu);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\조은이\\Desktop\\JAVA_P~1\\project\\legend.jpg"));
		lblNewLabel.setBounds(66, 70, 731, 337);
		f.getContentPane().add(lblNewLabel);
		
		JButton btnMatch = new JButton("매치");
		btnMatch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MatchUI m = new MatchUI();
				m.match();
			}
		});
		btnMatch.setForeground(Color.BLACK);
		btnMatch.setFont(new Font("휴먼모음T", Font.PLAIN, 25));
		btnMatch.setBackground(new Color(100, 149, 237));
		btnMatch.setBounds(435, 10, 168, 61);
		f.getContentPane().add(btnMatch);
		
		JButton btnRealD = new JButton("실시간데이터받기");
		btnRealD.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				db.rankingNameInsert();
			}
		});
		btnRealD.setFont(new Font("휴먼모음T", Font.PLAIN, 30));
		btnRealD.setBackground(new Color(100, 149, 237));
		btnRealD.setBounds(76, 417, 244, 61);
		f.getContentPane().add(btnRealD);
		
		f.setVisible(true);
	}
}
