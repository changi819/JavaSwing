package main;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;

import db.MemberDTO;
import db.ScoreDTO;
import db.Dbprocess;

import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;

public class Score {
	/**
	 * @wbp.parser.entryPoint
	 */
	public void scoreMain(ScoreDTO sdto) {
		JFrame f = new JFrame();
		Dbprocess db = new Dbprocess();
		Object header[] = {"승/패", "챔피언", "킬", "데스","어시스트"};			//j테이블 제목
		Object[][] content = db.setTable(sdto);						//j테이블의 행열 데이타		
		JTable table = new JTable(content,header);					//j테이블 행열정보와  j테이블 제목
		JScrollPane scrollPane = new JScrollPane(table);			//스크롤판에 j테이블 생성
		JLabel gamenick = new JLabel("");							
		JLabel lbID = new JLabel("nickname");
		JLabel lbTierT = new JLabel("tier");
		JLabel lbTier = new JLabel("tier");
		JButton btnNewButton = new JButton("전적 추가");
		f.setSize(700, 700);
		f.getContentPane().setBackground(new Color(100, 149, 237));
		f.getContentPane().setLayout(null);
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ScoreInsert insert = new ScoreInsert();				
				if(sdto.getNickname().equals(MemberDTO.nickname)) {	//db안에 게임아이디가 로그인한 게임아이디와 일치할경우
					insert.insertData(sdto);						//insert 창으로 이동			
				}else {												//그외는 모두
					JOptionPane.showMessageDialog(null, "로그인 하신 게임아이디와 일치하지않습니다.");		//출력
				}
			}
		});
		btnNewButton.setBounds(550, 10, 97, 33);
		f.getContentPane().add(btnNewButton);
		gamenick.setBounds(12, 10, 170, 50);
		f.getContentPane().add(gamenick);
		gamenick.setText("게임 아이디 : ");
		gamenick.setFont(new Font("휴먼모음T", Font.PLAIN, 25));
		
		lbID.setBounds(155, 10, 100, 50);
		f.getContentPane().add(lbID);
		lbID.setText(sdto.getNickname());
		lbID.setFont(new Font("휴먼모음T", Font.PLAIN, 25));

		lbTierT.setBounds(255, 10, 150, 50);
		f.getContentPane().add(lbTierT);
		lbTierT.setText("나의 티어 : ");
		lbTierT.setFont(new Font("휴먼모음T", Font.PLAIN, 25));
		
		lbTier.setBounds(400, 10, 150, 50);
		f.getContentPane().add(lbTier);
		lbTier.setText(sdto.getTier());
		lbTier.setFont(new Font("휴먼모음T", Font.PLAIN, 25));
		scrollPane.setBounds(12, 55, 520, 600);
		f.getContentPane().add(scrollPane);
		
		f.setVisible(true);
	}
}
