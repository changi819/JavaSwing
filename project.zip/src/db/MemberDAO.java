package db;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicOptionPaneUI.ButtonActionListener;

public class MemberDAO {

	String url = "jdbc:mysql://localhost:3708/member";
	String user = "root";
	String password = "1234";

	// 1. 회원가입
	/**
	 * @wbp.parser.entryPoint
	 */
	public void getNickName() {
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");
			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");
			// 3) sql문 결정
			String sql = "select nickname from member where id = "+"'"+MemberDTO.id+"'";
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("3. sql문 결정 ok...");
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				String nick = rs.getString("nickname");
				MemberDTO.nickname= nick;
			}

			// 4) sql문 전송
			System.out.println("4. sql문 전송 ok...");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//1. 회원가입
	//회원가입에 필요한 id, pw, nickname 넣어주기
	public void insert(String id, String pw, String nickname) {
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");

			// 3) sql문 결정
			String sql = "insert into member values (?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id); // DB부분만 1부터 시작
			ps.setString(2, pw);
			ps.setString(3, nickname);
			System.out.println("3. sql문 결정 ok...");

			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4. sql문 전송 ok...");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//2. 로그인
	//id중복확인없이 로그인을 누를 시 넘어가는 것을 방지하기 위해 새로 지정
	//로그인을 위해 id, pw값 boolean을 통해 확인
	public boolean select2(String id, String pw) {
		boolean result2 = false; //중복이 없는 경우
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");

			// 3) sql문 결정
			String sql1 = "select * from member where id = ? and pw = ?";
			PreparedStatement ps1 = con.prepareStatement(sql1);
			ps1.setString(1, id);
			ps1.setString(2, pw);
			//select를 통해 id, pw를 비교하여 같은 id, pw의 member변수를 가져옴
			System.out.println("3. sql문 결정 ok...");

			// 4) sql문 전송
			ResultSet rs = ps1.executeQuery();//select2문에서 rs.next()를 사용하기 위해 rs를 지정
			System.out.println("4. sql문 전송 ok..");
			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				result2 = true; //중복이 있는 경우
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result2; //boolean result2값을 반환
	}

	//3. 회원가입 id, pw, nickname 가져오기(배열)
	public MemberDTO select(MemberDTO dto) {//MemberDTO의 dto에서 가져오기
		MemberDTO dto2 = null;//시작할때 기본값 null로 지정
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");

			// 3) sql문 결정
			String sql1 = "select * from member where id = ?";
			PreparedStatement ps1 = con.prepareStatement(sql1);
			ps1.setString(1, dto.id); // DB부분만 1부터 시작

			System.out.println("3. sql문 결정 ok...");

			// 4) sql문 전송
			ResultSet rs = ps1.executeQuery();//select문에서 rs.next()를 사용하기 위해 rs를 지정
			System.out.println("4. sql문 전송 ok..");
			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				System.out.println("검색 결과가 있어요.!!");
				dto2 = new MemberDTO();//MemberDTO에 dto2를 생성
				String id = rs.getString(1);//id는 rs의 첫번째값
				dto2.setId(id);//dto2에 id를 저장

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto2;//id가 저장된 dto2값을 반환
	}
	//4. 아이디 중복처리
	//회원가입시 boolean을 통해 id중복확인
	public boolean check(String id) {
		boolean result = false; //중복이 없는 경우
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");

			// 3) sql문 결정
			String sql1 = "select * from member where id = ?";
			PreparedStatement ps1 = con.prepareStatement(sql1);
			ps1.setString(1, id);
			//select문을 통해 입력받은 id값을 비교하여 같은 member변수를 가져옴
			System.out.println("3. sql문 결정 ok...");

			// 4) sql문 전송
			ResultSet rs = ps1.executeQuery();//select문에서 rs.next()를 사용하기 위해 rs를 지정
			System.out.println("4. sql문 전송 ok..");
			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				result = true;//중복이 있는 경우
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;//result를 반환
	}

}