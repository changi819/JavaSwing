package db;


import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class Crawling {
   public ArrayList<String> name() {
      ArrayList<String> champname = new ArrayList();
      try {
         org.jsoup.Connection con = Jsoup.connect("https://www.op.gg/champion/statistics");
         Document doc = con.get();
         Elements list = doc.select(".champion-index__champion-list .champion-index__champion-item__name");
         
         for (int i = 0; i < list.size(); i++) {
            champname.add(list.get(i).text());
         }

      } catch (Exception e) {
         e.printStackTrace();
      }
      return champname;   
   }
}