package db;

public class MemberDTO {
	public static String nickname;
	public static String id;
	public static String pw;
	
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		MemberDTO.nickname = nickname;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		MemberDTO.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		MemberDTO.pw = pw;
	}
}
