package db;

public class TableScoreDTO {
	public String result;
	public String champ;
	public int murder;
	public int death;
	public int assi;
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getChamp() {
		return champ;
	}
	public void setChamp(String champ) {
		this.champ = champ;
	}
	public int getMurder() {
		return murder;
	}
	public void setMurder(int murder) {
		this.murder = murder;
	}
	public int getDeath() {
		return death;
	}
	public void setDeath(int death) {
		this.death = death;
	}
	public int getAssi() {
		return assi;
	}
	public void setAssi(int assi) {
		this.assi = assi;
	}
}
