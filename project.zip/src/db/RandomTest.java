package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Random;

public class RandomTest {
   static String url = "jdbc:mysql://localhost:3708/member";
   static String user = "root";
   static String password = "1234";
   
   public static void main(String[] args) {
      try {
         Class.forName("com.mysql.jdbc.Driver");
         Connection con = DriverManager.getConnection(url, user, password);
         String sql = "insert into score(nickname,result,champ,tier,murder,death,assist) values (?,?,?,?,?,?,?)";
         Crawling cr = new Crawling();
         ArrayList<String> name = cr.name();
         Random random = new Random();
         String[] result = { "Victory", "Defeat" };
         String[] tier = { "Iron", "Bronze", "Silver", "Gold", "Platinum", "Diamond", "Master", "Grand Master",
               "Challenger" };
         String[] position = { "Top", "Bottom", "Mid", "Support", "Jungle" };
         for (int i = 0; i < 100; i++) {
            PreparedStatement ps=con.prepareStatement(sql);
//            ps.setString(1, "test"+(i)%10);
            ps.setString(1, "test"+((i)%10));
            ps.setString(2, result[random.nextInt(2)]);
            ps.setString(3, ((String)name.get(random.nextInt(148))));
            ps.setString(4, (tier[random.nextInt(9)]));
            ps.setInt(5, random.nextInt(10));
            ps.setInt(6, random.nextInt(10));
            ps.setInt(7, random.nextInt(10));
            ps.executeUpdate();
         }
         
         String sql2 = "update score set tier = ? where nickname = ?";
         for (int i = 0; i < 10; i++) {
            PreparedStatement ps = con.prepareStatement(sql2);
            ps.setString(1, (tier[random.nextInt(9)]));
            ps.setString(2, "test"+((i)%10));
            ps.executeUpdate();
      }
         
//
//         String sql3 = "insert into matching values (?,?,?,?,?,?)";
//         for (int i = 0; i < 900; i++) {
//            Random r = new Random();
//            PreparedStatement ps = con.prepareStatement(sql3);
//            ps.setString(1, "test" + i);
//            ps.setString(2, "test" + i);
//            ps.setString(3, (tier[random.nextInt(9)]));
//            ps.setDouble(4, r.nextFloat());
//            ps.setString(5, ((String) name.get(random.nextInt(148))));
////            ps.setString(6, position[random.nextInt(5)]);
//            ps.setString(6, "Support");
//            ps.executeUpdate();
//         }

         System.out.println("전송완료");
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         
      }
   }

}