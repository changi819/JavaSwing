package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

import db.BbsDTO;
import db.MemberDTO;

public class BbsDAO {

	String url = "jdbc:mysql://localhost:3708/member?characterEncoding=utf8&serverTimezone=UTC";
	String user = "root";
	String password = "1234";

//1. 커뮤니티
	/**
	 * @wbp.parser.entryPoint
	 */

	// 1. 데이터베이스안에 있는 num컬럼 데이터 갖고오기
	public int[] getDbNumber() {
		int[] dbNum = null; // db num배열 선언
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");
			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");

			String sql = "select num from bbs";
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("3. sql문 결정 ok...");
			ResultSet rs = ps.executeQuery();
			rs.last(); // 커서를 제일 뒤로 옮김
			dbNum = new int[rs.getRow()]; // dbNum를 끝의 행까지
			rs.beforeFirst(); // 커서를 최상단으로 옮김
			for (int i = 0; rs.next(); i++) { // 커서를 다음으로 옮기면서
				dbNum[i] = Integer.parseInt(rs.getString("num")); // db에있는 num컬럼 데이터를 dbnum[i]에 전부 넣음
			}
			// 4) sql문 전송
			System.out.println("4. db sql문 전송 ok...");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dbNum; // db안에 num컬럼 데이터를 넣어준 배열 반환
	}

	public void insert(String id, String subject, String content) { // 저장할 id, subject, content 넣어줌
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");

			String sql = "insert into bbs(id, pw, subject, content) values (?, ?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, MemberDTO.id);
			ps.setString(2, MemberDTO.pw); // 따로 입력없이 static지정된 pw 가져옴
			ps.setString(3, subject);
			ps.setString(4, content);

			System.out.println("3. sql문 결정 ok...");

			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4. sql문 전송 ok...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// 2. 게시글 가져오기

	public ArrayList<BbsDTO> select() {
		// 매개변수(파라메터, parameter), 지역변수
		System.out.println("글 저장하다.");
		ArrayList<BbsDTO> list = new ArrayList<BbsDTO>();
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");
			String sql = "select * from bbs";
			PreparedStatement ps = con.prepareStatement(sql);

			System.out.println("3. sql문 결정 ok...");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				BbsDTO dto = new BbsDTO();
				dto.setId(rs.getString(2));
				dto.setSubject(rs.getString(4));
				dto.setContent(rs.getString(5));
				list.add(dto);
			}
			System.out.println("4. sql문 전송 ok...");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// 3. 글쓰기 수정
	public void update(String subject, String content, int value) {

		System.out.println("글 수정하다.");
		try {
			int[] num = this.getDbNumber();
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");
			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");
			// 3) sql문 결정
			String sql = "update bbs set subject = ?, content = ? where id = ? and num = ?";
			int[] dbNum = this.getDbNumber(); // db의 num을가져와 배열로
			System.out.println(dbNum[value - 1]);
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, subject);
			ps.setString(2, content);
			ps.setString(3, MemberDTO.id);
			ps.setInt(4, num[value - 1]);
			System.out.println("3. sql문 결정 ok...");
			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4. sql문 전송 ok...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//		 4. 글쓰기 삭제
	public void delete(int value) {
		System.out.println("글 삭제하다.");
		try {
			int[] num = this.getDbNumber();
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");
			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("DB연결 ok...");
			// 입력한 id와 pw과 DB와 같다면
			// 3) sql문 결정
			String sql = "delete from bbs where num = ?";
			int[] dbNum = this.getDbNumber();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, num[value - 1]);
			System.out.println("3. sql문 결정 ok...");
			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4. sql문 전송 ok...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 5. id, pw 중복 관리
	public boolean check(String id, String pw) {
		boolean result = false;
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");
			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");
			// 3) sql문 결정
			String sql1 = "select * from member where id = ? and pw = ?";
			PreparedStatement ps1 = con.prepareStatement(sql1);
			ps1.setString(2, id);
			ps1.setString(3, pw);
			System.out.println("3. sql문 결정 ok...");
			// 4) sql문 전송
			ResultSet rs = ps1.executeQuery();
			System.out.println("4. sql문 전송 ok..");
			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}