package db;

public class RealDataDTO {
	public static int[] id;
	public static String[] result;
	public static String[] champ;
	public static int[] murder;
	public static int[] death;
	public static int[] assi;
	public static String[] name = {"Gen+G+Karis","Youtube+Thal","Gen+G+Ruler","T1+Gumayusi",
			"Destiny","Gen+G+Bonnie","znhy","DWG ShowMaker","SPG Jaguar","GIDE0N","Gen+G+Clid","JustLikeThatKR",
			"KT+Malrang","SANDBOX+Natalie","TlGER","huhushengwei","DWG+Canyon","sry1sry1","me1duiyou","HLE+Haru"};
	
	public static int[] getid() {
		return id;
	}
	public static void setid(int[] id) {
		RealDataDTO.id=id;
	}
	
	public static String[] getResult() {
		return result;
	}
	public static void setResult(String[] result) {
		RealDataDTO.result = result;
	}
	public static String[] getChamp() {
		return champ;
	}
	public static void setChamp(String[] champ) {
		RealDataDTO.champ = champ;
	}
	public static int[] getMurder() {
		return murder;
	}
	public static void setMurder(int[] murder) {
		RealDataDTO.murder = murder;
	}
	public static int[] getDeath() {
		return death;
	}
	public static void setDeath(int[] death) {
		RealDataDTO.death = death;
	}
	public static int[] getAssi() {
		return assi;
	}
	public static void setAssi(int[] assi) {
		RealDataDTO.assi = assi;
	}

}
