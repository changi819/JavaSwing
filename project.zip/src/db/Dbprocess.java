package db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import main.Score;
import main.Search;

public class Dbprocess {
	String url = "jdbc:mysql://localhost:3708/member";
	String user = "root";
	String password = "1234";
	Score s = new Score();
	Search search = new Search();
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	
	// db안에 있는 것들을 2차원 오브젝트로 반환함
	public Object[][] searchRealDb() {
		Object[][] obj = null;
		try {
			// 커넥터설정
			Class.forName("com.mysql.jdbc.Driver");
			// db연결
			con = DriverManager.getConnection(url, user, password);
			// sql문 결정
			String sql = "select nickname,result,champ,murder,death,assist from score";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			rs.last();
			Object arr[][] = new Object[rs.getRow()][6]; // 2차원 오브젝트 선언
			rs.beforeFirst();
			for (int i = 0; rs.next(); i++) { // db 안에있는 자료 2차원오브젝트에 대입함.
				int j = 0;
				for (j = 1; j < 7; j++) {
					arr[i][j - 1] = rs.getString(j);
				}
			}
			obj = arr;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
				ps.close();
				rs.close();
			} catch (Exception e2) {
			}
		}
		return obj;
	}

	//중복검사를 거친후 데이터 크롤링한거 DB에 넣기
	public void insertRealData(int index) {
		try {
			// 커넥터설정
			Class.forName("com.mysql.jdbc.Driver");
			// db연결
			con = DriverManager.getConnection(url, user, password);
			// sql문 결정
			String sql = "insert into score(nickname,result,champ,tier,murder,death,assist) values (?,?,?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, RealDataDTO.name[index]);// 게임아이디 입력
			ps.setString(2, RealDataDTO.result[index]); // 승패 입력
			ps.setString(3, RealDataDTO.champ[index]); // 챔피언 입력
			ps.setString(4, "Challenger"); // 티어 입력
			ps.setInt(5, RealDataDTO.murder[index]); // 킬 입력
			ps.setInt(6, RealDataDTO.death[index]); // 데스입력
			ps.setInt(7, RealDataDTO.assi[index]); // 어시스트 입력
			// sql문 전송
			ps.executeUpdate();
			System.out.println("추가 완료 ");
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
				ps.close();
			} catch (Exception e2) {
			}
		}
	}
//크롤링한 데이터의 중복된 값을 지워주는 기능
	public void deleteDB(int index) {
		try {
			// 커넥터설정
			Class.forName("com.mysql.jdbc.Driver");
			// db연결
			con = DriverManager.getConnection(url, user, password);
			// sql문 결정
			String sql = "delete from score where nickname = ? and result = ? and champ= ? and murder = ? and death= ? and assist= ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, RealDataDTO.name[index]); // 게임아이디의 인덱스 찾아서 sql문에 넣음
			ps.setString(2, RealDataDTO.result[index]); // 승패
			ps.setString(3, RealDataDTO.champ[index]); // 챔피언 입력
			ps.setInt(4, RealDataDTO.murder[index]); // 킬 입력
			ps.setInt(5, RealDataDTO.death[index]); // 데스입력
			ps.setInt(6, RealDataDTO.assi[index]); // 어시스트 입력
			ps.executeUpdate();
			// sql문 전송
			System.out.println("중복삭제 완료 ");
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
				ps.close();
			} catch (Exception e2) {
			}
		}
	}

	// 데이터크롤링한거 중복확인
	public void duplicatedata() {
		Object[][] arr = this.searchRealDb(); //2차원 오브젝트 선언과동시에 이클래스에 searchRealDb메소드의 반환값을 넣음
		int index = 0;							//길이
		//2차반복문을 통해 db에 있는데이터들과 RealDataDTO에 있는 데이터를 중복검사함
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				index = i;
				if (i >= 20) {			
					//인덱스의 길이가 최대20인데 넘으면 인덱스가 초과하기때문에
					//인덱스길이를 다시 20크기만큼 분해해야됌.
					index = i % 20;	//20길이만큼 분해
				}	//크롤링한 데이터의 정보들의 인덱스와 db를 테이블화 하여 정보가 같은것을 검색
				if (RealDataDTO.result[index].equals(arr[j][1])
						&& RealDataDTO.champ[index].equals(arr[j][2])
						&& RealDataDTO.murder[index] == Integer.parseInt((String) arr[j][3])
						&& RealDataDTO.death[index] == Integer.parseInt((String) arr[j][4])
						&& RealDataDTO.assi[index] == Integer.parseInt((String) arr[j][5])) {
					//정보들이 같다면
					System.out.println("크롤링 " + i + "번 db " + j + " 번 중복 ");
					this.deleteDB(index); //중복되는 인덱스를 매개변수로 넣고 메소드를 호출
				}
			}
		}
		//중복검사를 하여 중복이 된정보들은 지워버리고 다시 디비에 넣음
		for (int i = 0; i < RealDataDTO.champ.length; i++) {
			this.insertRealData(i);
		}
	}
	// 랭킹 
	public void rankingNameInsert() {
		for (int i = 0; i < 1; i++) {
			this.realdata(i);
		}
	}

	// 데이터 크롤링
	public void realdata(int index) {
		try { // 서라운드 윗 . 트라이케치.
			org.jsoup.Connection con = Jsoup.connect("https://www.op.gg/summoner/userName=" + RealDataDTO.name[index]);// 제이숲사이트	연결
			Document doc = con.get();// 문서 가져온다.
			Elements list1 = doc.select(".GameItemWrap .KDA .KDA span.kill"); // 킬 데이터 크롤링
			Elements list2 = doc.select(".GameItemWrap .KDA .KDA span.Death");// 데스	데이터 크롤링
			Elements list3 = doc.select(".GameItemWrap .KDA .KDA span.Assist");// 어시 데이터 크롤링
			Elements list4 = doc.select(".GameResult"); // 결과 데이터 크롤링
			Elements list5 = doc.select(".GameSettingInfo .ChampionName a"); // 챔피언 이름 데이터 크롤링
			int[] murder = new int[list1.size()];			//int형 배열을 리스트1 사이즈만큼 선언한다.
			int[] death = new int[list2.size()];			//int형 배열을 리스트2 사이즈만큼 선언한다.
			int[] assi = new int[list3.size()];				//int형 배열을 리스트3 사이즈만큼 선언한다.
			String[] result = new String[list4.size()];		//String형 배열 리스트 4사이즈만큼 선언한다.
			String[] champ = new String[list5.size()];		//String형 배열 리스트 5 사이즈만큼 선언한다.

			for (int i = 0; i < list1.size(); i++) {
				murder[i] = Integer.parseInt(list1.get(i).text());//리스트1의 텍스트를 인트형으로 변환시키고 그 정보를 인트형배열에 넣는다
				death[i] = Integer.parseInt(list2.get(i).text()); //리스트2의 텍스트를 인트형으로 변환시키고 그 정보를 인트형배열에 넣는다
				assi[i] = Integer.parseInt(list3.get(i).text());  //리스트3의 텍스트를 인트형으로 변환시키고 그 정보를 인트형배열에 넣는다
				result[i] = list4.get(i).text();				  //리스트4의 텍스트를 문자열 배열에 넣음
				champ[i] = list5.get(i).text();					  //리스트5의 텍스트를 문자열 배열에 넣음
			}
			// 정적 메소드사용하여 배열 저장
			RealDataDTO.setMurder(murder); 
			RealDataDTO.setDeath(death);   
			RealDataDTO.setAssi(assi);
			RealDataDTO.setResult(result);
			RealDataDTO.setChamp(champ);
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.duplicatedata();		//이 클래스안에 duplicatedata 메소드 실행
	}

	// 전적 테이블 만들기
	public Object[][] setTable(ScoreDTO sdto) {
		Object[][] obj = null;				//반환할 2차원 오브젝트 선언
		try {
			// 커넥터설정
			Class.forName("com.mysql.jdbc.Driver");
			// db연결
			con = DriverManager.getConnection(url, user, password);
			// sql문 결정
			String sql = "select result,champ,murder,death,assist from score where nickname =?";
			ps = con.prepareStatement(sql);
			ps.setString(1, sdto.getNickname());		//score데이터의 닉네임을 가져와 sql문장에 대입
			rs = ps.executeQuery();
			rs.last();
			Object arr[][] = new Object[rs.getRow()][5]; // 2차원 오브젝트 선언
			rs.beforeFirst();
			for (int i = 0; rs.next(); i++) { // db 안에있는 자료 2차원오브젝트에 대입함.
				int j = 0;
				for (j = 1; j < 6; j++) {
					arr[i][j - 1] = rs.getString(j);
				}
			}
			obj = arr;		//반복문으로 데이터 넣은것을 obj에게 대입
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
				ps.close();
				rs.close();
			} catch (Exception e2) {
			}
		}
		return obj;			//데이터를 넣은것을 반환한다.
	}

	// 게임아이디 검색
	public ScoreDTO searchNick(ScoreDTO sdto) {
		try {
			// 커넥터설정
			Class.forName("com.mysql.jdbc.Driver");
			// db연결
			con = DriverManager.getConnection(url, user, password);
			// sql문 결정
			String sql = "select * from score";				//데이터베이스에 스코어테이블 모두 갖고오기
			ps = con.prepareStatement(sql);					
			rs = ps.executeQuery();
			if(rs.next()) {
				sdto.setTier(rs.getString("tier"));				//DB안에 저장된티어를 가지고와서 스코어DTO 티어에 저장
			}else {
				System.out.println("티어못찾음오류");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
				ps.close();
				rs.close();
			} catch (Exception e2) {
			}
		}
		return sdto;
	}

	// 전적입력
	public void insert(ScoreDTO sdto) {
		try {
			// 커넥터설정
			Class.forName("com.mysql.jdbc.Driver");
			// db연결
			con = DriverManager.getConnection(url, user, password);
			// sql문 결정
			if (sdto.nickname.equals(MemberDTO.nickname)) {						//스코어DTO 닉네임변수가 로그인한 정보의 닉네임변수와 같으면 실행
				String sql = "insert into score(nickname,result,champ,tier,murder,death,assist) values (?,?,?,?,?,?,?)";	//스코어테이블에 정보 입력
				ps = con.prepareStatement(sql);
				ps.setString(1, sdto.nickname);// 게임아이디 입력
				ps.setString(2, sdto.result); // 승패 입력
				ps.setString(3, sdto.champ); // 챔피언 입력
				ps.setString(4, sdto.tier); // 티어 입력
				ps.setInt(5, sdto.murder); // 킬 입력
				ps.setInt(6, sdto.death); // 데스입력
				ps.setInt(7, sdto.assist); // 어시스트 입력
				// sql문 전송
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null, "추가완료.");
			} else {															//스코어DTO와 닉네임이 다르다면
				JOptionPane.showMessageDialog(null, "접속하신 닉네임과 다릅니다.");		//실행
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
				ps.close();
			} catch (Exception e2) {
			}
		}
	}
}