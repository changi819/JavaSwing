package db;

public class DTO {
   String nickname;
   String result;
   String tier;
   String champ;
   double rate;
   String position;
   int kill;
   int death;
   int assist;
   int win;
   int count;
   
   public String getNickname() {
      return nickname;
   }
   public void setNickname(String nickname) {
      this.nickname = nickname;
   }
   public String getResult() {
      return result;
   }
   public void setResult(String result) {
      this.result = result;
   }
   public String getTier() {
      return tier;
   }
   public void setTier(String tier) {
      this.tier = tier;
   }
   public String getChamp() {
      return champ;
   }
   public void setChamp(String champ) {
      this.champ = champ;
   }
   public double getRate() {
      return rate;
   }
   public void setRate(double rate) {
      this.rate = rate;
   }
   public String getPosition() {
      return position;
   }
   public void setPosition(String position) {
      this.position = position;
   }
   public int getKill() {
      return kill;
   }
   public void setKill(int kill) {
      this.kill = kill;
   }
   public int getDeath() {
      return death;
   }
   public void setDeath(int death) {
      this.death = death;
   }
   public int getAssist() {
      return assist;
   }
   public void setAssist(int assist) {
      this.assist = assist;
   }
   public int getWin() {
      return win;
   }
   public void setWin(int win) {
      this.win = win;
   }
   public int getCount() {
      return count;
   }
   public void setCount(int count) {
      this.count = count;
   }

   
}