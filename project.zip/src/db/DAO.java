package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DAO {
   static String url = "jdbc:mysql://localhost:3708/member";
   static String user = "root";
   static String password = "1234";
   Connection con;
   PreparedStatement ps;
   ResultSet rs;
   
   public ArrayList<DTO> select(String s) {
      ArrayList<DTO> list = new ArrayList<DTO>();

      try {
         Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection(url, user, password);

         String sql = "select * from score where champ = '"+ s +"'"; //챔피언 이름으로 검색한 모든 결과

         ps = con.prepareStatement(sql);
      
         rs = ps.executeQuery();

         while (rs.next()) {
            DTO dto = new DTO();
            dto.setNickname(rs.getString(2));
            dto.setResult(rs.getString(3));
            dto.setTier(rs.getString(5));
            dto.setKill(rs.getInt(6));
            dto.setDeath(rs.getInt(7));
            dto.setAssist(rs.getInt(8));
            list.add(dto);
         }

      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            con.close();
            ps.close();
            rs.close();
         } catch (Exception e2) {
         }
      }
      return list;
   }
   
   public String[] select2() {
      String[] list = new String[150];
      try {
         Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection(url, user, password);

         String sql = "select champ, sum(if(result='Victory', 1, 0)) / sum(if(result='Victory', 1, if(result='Defeat', 1, 0))) sort_ord"
               + " from score group by champ order by sort_ord desc"; // 승률 계산 후 내림차순으로 정렬

         ps = con.prepareStatement(sql);
         rs = ps.executeQuery();
         int i = 0;
         while (rs.next()) {
            list[i] = rs.getString(1);
            i++;
         }
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            con.close();
            ps.close();
            rs.close();
         } catch (Exception e2) {
         }
      }
      return list;

   }
   
   public String[] select3() {
      String[] list = new String[148];
      
      try {
         Class.forName("com.mysql.jdbc.Driver");

         con = DriverManager.getConnection(url, user, password);

         String sql = "select champ, count(*) count" // 플레이된 횟수별로 내림차순 정렬
               + " from score group by champ order by count desc";

         ps = con.prepareStatement(sql);
         rs = ps.executeQuery();
         int i = 0;
         while (rs.next()) {
            list[i] = rs.getString(1);
            i++;
         }
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            con.close();
            ps.close();
            rs.close();
         } catch (Exception e2) {
         }
      }

      return list;

   }
   public ArrayList select4(String nick) {
      ArrayList list = new ArrayList();
      try {
         Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection(url, user, password);

         String sql = "select tier, sum(if(result='Victory', 1, 0)) / sum(if(result='Victory', 1, if(result='Defeat', 1, 0)))"
               + " from score where nickname = ?";
         ps = con.prepareStatement(sql); 
         ps.setString(1, nick);
         rs = ps.executeQuery();

         while (rs.next()) {
            list.add(rs.getString(1));
            list.add(rs.getDouble(2));
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
      return list;

   }
   public void insert(String id, String nick, String tier, double rate, String champ, String position) {
      try {
         Class.forName("com.mysql.jdbc.Driver");

         con = DriverManager.getConnection(url, user, password);

         String sql = "insert into matching values ( ?, ?, ?, ?, ?, ? )"; // 아이디, 닉네임, 티어, 승률, 챔, 라인
         ps = con.prepareStatement(sql);
         
         ps.setString(1, id);
         ps.setString(2, nick);
         ps.setString(3, tier);
         ps.setDouble(4, rate);
         ps.setString(5, champ);
         ps.setString(6, position);

         ps.executeUpdate();

      } catch (Exception e) {
         e.printStackTrace();
      }

   }
   public boolean search(String id) {
      boolean result = false;
      try {
         Class.forName("com.mysql.jdbc.Driver");

         con = DriverManager.getConnection(url, user, password);

         String sql = "select * from matching where id = ?"; // 아이디, 닉네임, 티어, 승률, 챔, 라인
         ps = con.prepareStatement(sql);
         ps.setString(1, id);
         rs = ps.executeQuery();
         if (rs.next()) {
            result = true;
         }
         
      } catch (Exception e) {
         e.printStackTrace();
      }
      return result;
   }
   public ArrayList search2(String nick) {
      ArrayList list = new ArrayList();
      try {
         Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection(url, user, password);

         String sql = "select * from matching where nickname = ?"; // 아이디, 닉네임, 티어, 승률, 챔, 라인
         ps = con.prepareStatement(sql);
         ps.setString(1, nick);
         rs = ps.executeQuery();
         
         if (rs.next()) {
            list.add(rs.getString(5));
            list.add(rs.getString(6));
         }
         
      } catch (Exception e) {
         e.printStackTrace();
      }
      return list;
   }
   public ArrayList<DTO> search3(String tier, String champ, String position) {
      ArrayList<DTO> list = new ArrayList();
      try {
         Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection(url, user, password);

         String sql = "select * from matching where tier = ? and champ = ? and position = ? order by rate desc"; 
         ps = con.prepareStatement(sql);
         ps.setString(1, tier);
         ps.setString(2, champ);
         ps.setString(3, position);
         rs = ps.executeQuery();
         
         while (rs.next()) {
            DTO dto = new DTO();
            dto.setNickname(rs.getString(2));
            dto.setTier(tier);
            dto.setRate(rs.getDouble(4));
            dto.setChamp(champ);
            dto.setPosition(position);
            list.add(dto);
         }
         
      } catch (Exception e) {
         e.printStackTrace();
      }
      return list;
   }

   public void delete(String id) {
      try {
         Class.forName("com.mysql.jdbc.Driver");

         con = DriverManager.getConnection(url, user, password);

         String sql = "delete from matching where id = ?";
         ps = con.prepareStatement(sql);
         ps.setString(1, id);
         ps.executeUpdate();

      } catch (Exception e) {
         e.printStackTrace();
      }

   }
   public ArrayList<DTO> select5() {
      ArrayList<DTO> list = new ArrayList<DTO>();
      try {
         Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection(url, user, password);

         String sql = "select nickname, sum(if(result='Victory', 1, 0)) / sum(if(result='Victory', 1, if(result='Defeat', 1, 0))) sort_ord,"
               + " sum(if(result='Victory', 1, if(result='Defeat', 1, 0))), sum(if(result='Victory', 1, 0)), tier from score group by nickname"
               + " order by sort_ord desc"; // 게임 ID 별 승률, 플레이 수, 이긴 횟수, 티어
         ps = con.prepareStatement(sql);
         rs = ps.executeQuery();

         while (rs.next()) {
            DTO dto = new DTO();
            dto.setNickname(rs.getString(1));
            dto.setRate(rs.getDouble(2));
            dto.setCount(rs.getInt(3));
            dto.setWin(rs.getInt(4));
            dto.setTier(rs.getString(5));
            list.add(dto);
         }
      } catch (Exception e) {
         e.printStackTrace();
      }

      return list;

   }

   public ArrayList<DTO> select6(String tier) {
      ArrayList<DTO> list = new ArrayList<DTO>();
      try {
         Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection(url, user, password);

         String sql = "select nickname, sum(if(result='Victory', 1, 0)) / sum(if(result='Victory', 1, if(result='Defeat', 1, 0))) sort_ord,"
               + " sum(if(result='Victory', 1, if(result='Defeat', 1, 0))), sum(if(result='Victory', 1, 0)) from score where tier = '"
               + tier + "'" + " group by nickname order by sort_ord desc"; // 티어 별 게임 ID, 승률, 플레이수, 이긴 횟수
         ps = con.prepareStatement(sql);
         rs = ps.executeQuery();

         while (rs.next()) {
            DTO dto = new DTO();
            dto.setNickname(rs.getString(1));
            dto.setRate(rs.getDouble(2));
            dto.setCount(rs.getInt(3));
            dto.setWin(rs.getInt(4));
            list.add(dto);
         }
      } catch (Exception e) {
         e.printStackTrace();
      }

      return list;

   }

   public ArrayList<DTO> select7() {
      ArrayList<DTO> list = new ArrayList();
      try {
         Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection(url, user, password);

         String sql = "select count(*), tier from score group by tier";
         ps = con.prepareStatement(sql);
         rs = ps.executeQuery();

         while (rs.next()) {
            DTO dto = new DTO();
            dto.setCount(rs.getInt(1));
            dto.setTier(rs.getString(2));
            list.add(dto);
         }
      } catch (Exception e) {
         e.printStackTrace();
      }

      return list;

   }
   
}