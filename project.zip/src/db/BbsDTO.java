package db;

public class BbsDTO {
	public String subject;
	public String content;
	public String id;
	public String pw;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "BbsDTO [subject=" + subject + ", content=" + content + ", id=" + id + ", pw=" + pw + "]";
	}
	
		
}